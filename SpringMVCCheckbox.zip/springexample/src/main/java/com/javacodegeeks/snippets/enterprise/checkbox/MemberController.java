package com.javacodegeeks.snippets.enterprise.checkbox;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.javacodegeeks.snippets.enterprise.checkbox.model.Member;


@Controller
@RequestMapping("/member.htm")
public class MemberController {

	@RequestMapping(method = RequestMethod.GET)
	public String initForm(Model model) {
		Member member = new Member();
		List<String> preCheckedVals = new ArrayList<String>();
		preCheckedVals.add("Yoga");
		member.setCourses(preCheckedVals);
		model.addAttribute("member", member);
		List<String> courses = new ArrayList<String>();
		courses.add("Yoga");
		courses.add("Stretching");
		courses.add("Pilates");
		courses.add("Aerobic");
		courses.add("Oriental");
		model.addAttribute("courses", courses);
		return "member";
	}

	@RequestMapping(method = RequestMethod.POST)
	public String submitForm(Model model, Member member,
			BindingResult result) {
		System.out.println("Controller runs");
		model.addAttribute("member", member);
		return "successMember";
	}

}
