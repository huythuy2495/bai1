package com.techprimers.cloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SleuthClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SleuthClientApplication.class, args);
	}
}
