package com.javacodegeeks.snippets.enterprise.dropdown.model;

public class Colour {

	private String colourName;

	public String getColourName() {
		return colourName;
	}

	public void setColourName(String colourName) {
		this.colourName = colourName;
	}
}
