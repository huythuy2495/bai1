package com.javacodegeeks.snippets.enterprise.radiobutton.model;


public class Order {

	String size;
	
	String flavors;

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getFlavors() {
		return flavors;
	}

	public void setFlavors(String flavors) {
		this.flavors = flavors;
	}
	
}
