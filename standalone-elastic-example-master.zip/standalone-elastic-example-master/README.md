# standalone-elastic-example
Accessing Standalone Elastic Search Instance from a Spring Boot/MVC application
