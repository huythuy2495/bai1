package com.javacodegeeks.snippets.enterprise.hidden.model;

public class HiddenMessage {

	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}
