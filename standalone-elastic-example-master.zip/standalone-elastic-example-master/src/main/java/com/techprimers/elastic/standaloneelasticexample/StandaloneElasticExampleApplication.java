package com.techprimers.elastic.standaloneelasticexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StandaloneElasticExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(StandaloneElasticExampleApplication.class, args);
	}
}
