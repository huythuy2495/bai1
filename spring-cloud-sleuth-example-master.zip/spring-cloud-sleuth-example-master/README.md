# spring-cloud-sleuth-example

Contains 'sleuth-server' and 'sleuth-client' which can be treated as two different microservices.
sleuth-client calls the sleuth-server to retrieve response. 
Logs are placed in both Server and Client to show the Log traceability using Spring Cloud Sleuth.
