# Spring Reactive Example using MongoDB

- Uses Spring Boot 2.0.0-M3 with Spring 5 Framework using Reactor Streams for Reactive REST endpoints
- Uses Spring MVC Style Resource push.