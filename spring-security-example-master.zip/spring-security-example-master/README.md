# Spring Security Example
This app has Spring Boot Application enabled with Spring Security using InMemory Authentication and Authorization.
